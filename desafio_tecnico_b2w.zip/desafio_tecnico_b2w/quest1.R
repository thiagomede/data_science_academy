#pacotes
packs <- c("dplyr","readxl","tydiverse","openxlsx","ggplot2")


# Instala e carrega pacotes, caso não tenham sidos anteriormente
lapply(packs, FUN = function(x){
  if (!require(x, character.only = TRUE)) {
    install.packages(x, dependencies = TRUE)
    require(x, character.only = TRUE)
  }
})


# Atribuindo diretório
dir_source <- tryCatch({
  dirname(rstudioapi::getSourceEditorContext()$path)
}, 
error = function(err){return(NULL)}
)

if (is.null(dir_source)){
  tcltk::tk_choose.dir(caption = 'Selecione o diretorio')
}

setwd(dir_source)


######LENDO A BASE
df1=read.xlsx('desafio.xlsx',sheet = 'BASE - Pergunta 1')
df_rj=filter(df1, Estado == 'RJ')
df_sp=filter(df1, Estado == 'SP')


#### Agrupando e calculando o ROI para RJ
df_rj2=df_rj %>% group_by(Grupo.do.Teste) %>% summarise(
  R_PROD=sum(Receita.de.Produto),
  R_FRETE=sum(Receita.de.Frete),
  D_FRETE=sum(Despesa.de.Frete)) %>% ungroup()

df_rj2=data.frame(df_rj2[,-1], row.names = df_rj2$Grupo.do.Teste)

auxrj=apply(df_rj2,2,sum)
df_rj2['TOTAL',1:3]=auxrj
roi_rj=   (df_rj2["B","R_PROD"]-df_rj2["A","R_PROD"])/(df_rj2["TOTAL","D_FRETE"]-df_rj2["TOTAL","R_FRETE"])
roi_rj=data.frame('VAL'=c(13,roi_rj),"KEY"=factor(c('meta','real')))


#Plotando resultado RJ
ggplot(roi_rj,aes(x=KEY,y=VAL,fill=KEY))+geom_col()+ylab('ROI')+xlab('')+
  geom_text(aes(label = round(VAL,2)), vjust = -0.5)+ggtitle('Retorno Rio de Janeiro')+
  scale_fill_discrete(name = "Retorno observado", labels=c("meta", "real"))+
  theme_classic()


#### Agrupando e calculando o ROI para SP
df_sp2=df_sp %>% group_by(Grupo.do.Teste) %>% summarise(
  R_PROD=sum(Receita.de.Produto),
  R_FRETE=sum(Receita.de.Frete),
  D_FRETE=sum(Despesa.de.Frete)) %>% ungroup()

df_sp2=data.frame(df_sp2[,-1], row.names = df_sp2$Grupo.do.Teste)

auxsp=apply(df_sp2,2,sum)
df_sp2['TOTAL',1:3]=auxsp
roi_sp=   (df_sp2["B","R_PROD"]-df_sp2["A","R_PROD"])/(df_sp2["TOTAL","D_FRETE"]-df_sp2["TOTAL","R_FRETE"])
roi_sp=data.frame('VAL'=c(13,roi_sp),"KEY"=factor(c('meta','real')))


#Plotando resultado SP
ggplot(roi_sp,aes(x=KEY,y=VAL,fill=KEY))+geom_col()+ylab('ROI')+xlab('')+
  geom_text(aes(label = round(VAL,2)), vjust = -0.5)+ggtitle('Retorno São Paulo')+
  scale_fill_discrete(name = "Retorno observado", labels=c("meta", "real"))+
  theme_classic()

