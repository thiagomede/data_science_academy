
packs <- c("dplyr","readxl","tydiverse","openxlsx","ggplot2","h2o",'plyr')


# Instala e carrega pacotes, caso não tenham sido anteriormente
lapply(packs, FUN = function(x){
  if (!require(x, character.only = TRUE)) {
    install.packages(x, dependencies = TRUE)
    require(x, character.only = TRUE)
  }
})

# 
dir_source <- tryCatch({
  dirname(rstudioapi::getSourceEditorContext()$path)
}, 
error = function(err){return(NULL)}
)

if (is.null(dir_source)){
  tcltk::tk_choose.dir(caption = 'Selecione o diretorio')
}

setwd(dir_source)



#########################
######LENDO A BASE
df1=read.xlsx('desafio.xlsx',sheet = 'BASE - Pergunta 2')


# Primeiro Tratamento de dados -Substituindo os NAs por 0
auxNA=(which(is.na(df1[,'QTD_PED_6M'])))
colunas_na=c('QTD_PED_6M','QTD_PED_3M','QTD_PED_1M',
             'APP_6M','MARKETPLACE_6M','TOP3_DEPTOS_6M')

df1[auxNA,colunas_na]=0
df1[auxNA,"TIPO_PAG_MAIS_USADO_6M"]='NENHUM'



# Primeira Visualização dos dados - Variáveis não binárias
col_nbin=c('QTD_PED_6M','QTD_PED_3M','QTD_PED_1M')
summary(df1[,col_nbin])
boxplot(df1[,col_nbin])
boxplot(df1[,col_nbin],outline = F)

sort(unique(df1[,'QTD_PED_6M']))
sort(unique(df1[,'QTD_PED_3M']))
sort(unique(df1[,'QTD_PED_1M']))


# Segundo tratamento de dados - Agrupando as variáveis não binárias 
#e passando as char para factor

aux_6m=c(-1,0,1,5,10,20,30,100)
aux_3m=c(-1,0,1,5,10,20,30,100)
aux_1m=c(-1,0,1,5,10,20)


texto_6m=c('0','1','2 a 5','6 a 10','11 a 20','21 a 30', '31 a 100' )
texto_3m=c('0','1','2 a 5','6 a 10','11 a 20','21 a 30', '31 a 100' )
texto_1m=c('0','1','2 a 5','6 a 10','11 a 20' )

df2=df1%>% 
  mutate(QTD_PED_6M=cut(QTD_PED_6M,aux_6m,labels=texto_6m),
         QTD_PED_3M=cut(QTD_PED_3M,aux_3m,labels=texto_3m),
         QTD_PED_1M=cut(QTD_PED_1M,aux_1m,labels=texto_1m)) %>% 
  mutate_if(is.character, as.factor) %>% 
  mutate(id_cliente_hash=as.character(id_cliente_hash)) %>% 
  mutate_if(is.double,as.factor) %>% 
  mutate(APP_6M=revalue( APP_6M,c("0"="não", "1"="sim")),
         MARKETPLACE_6M=revalue( MARKETPLACE_6M,c("0"="não", "1"="sim")),
         TOP3_DEPTOS_6M=revalue( TOP3_DEPTOS_6M,c("0"="não", "1"="sim")),
         C_CUPOM=revalue( C_CUPOM,c("0"="não", "1"="sim")),
         C_APP=revalue( C_APP,c("0"="não", "1"="sim")),
         C_MARKETPLACE=revalue( C_MARKETPLACE,c("0"="não", "1"="sim")),)


# Segunda Visualização dos dados - Relação da target com as variáveis disponíveis

graf=function(df2,x,eixo_x){
  x2=sym(x)
  a=ggplot(df2,aes(x=!!x2,fill=F_RECOMPROU))+geom_bar(position = 'fill')+
    labs(title=paste('Proporção de recompras por ',x))+ 
    theme(axis.text.x = element_text(size=6))+ylab('Prop. Recompras')+
    xlab(eixo_x[x])+
    scale_fill_discrete(name = "Recompra", labels=c("não", "sim"))+
    theme_classic()
  return(a)
  }

aux_nomes=c('Quantidade pedidos em 6 meses',
             'Quantidade pedidos em 3 meses',
             'Quantidade pedidos em 1 meses',
             'Houve compra via APP em 6 meses?',
             'Houve compra Marketplace em 6 meses?',
             'Houve compra nos top 3 departamentos em 6 meses?',
             'Tipo de pagamento mais utilizado em 6 meses',
             'Usou um cupom no seu último pedido?',
             'Usou o app no seu último pedido?',
             'Tipo de pagamento no último pedido',
             'Último pedido do cliente foi Marketplace?',
             'Departamento comprado no último pedido do cliente')
  
names(aux_nomes)=names(df2)[-c(1,length(names(df2)))]

lista=list()
for(i in 2:(ncol(df2)-1)){
  lista[[i-1]]=graf(df2,names(df2)[i],eixo_x = aux_nomes)
}


# RANDOM FOREST PRA VER A VARIÁVEL MAIS SIGNIFICATIVA
df3=df2 %>% select(-id_cliente_hash) 

h2o.init()
df3=as.h2o(df3)

predictors1 <- c(names(df3)[-c(length(df3))])
response <- "F_RECOMPROU"

mm1<- h2o.randomForest(x = predictors1, y = response,
                       training_frame = df3,
                       seed = 71)
plot(mm1)
summary(mm1)
pred=predict(mm1,df3)
pred2=as.data.frame(pred)


#Ordenando por probabilidade de Recompra
df_final=cbind(df2,pred2) %>% arrange(desc(p1)) 
df_final=dplyr::rename(df_final,Probab_Recompra=p1) %>% select(-p0) %>% 
  mutate_if(is.character,as.double) %>% 
  mutate(id_cliente_hash=format(id_cliente_hash,scientific = F))
write.csv2(df_final,'cliente_prob.csv')

#Plotando as variáveis mais significativas
names(summary(mm1))
importance=summary(mm1)[c('variable','percentage')]
importance$acumul=cumsum(importance$percentage)

ggplot(importance,aes(x=1:12,y=acumul))+geom_line()+
  scale_x_discrete(name ="Número de variáveis", limits=factor(c(1:12)))+
theme_classic()+geom_vline(xintercept =5,color='green',linetype=2)+
  geom_hline(yintercept =importance$acumul[5] ,color='green',linetype=2)+
  ylab('Perc. acumulada')+
  ggtitle('Porcentagem acumulada da Importância por nº de variáveis no modelo')
